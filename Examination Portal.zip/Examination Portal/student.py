import csv
def add_student():
    f=open("student.csv",'a',newline='')
    w=csv.writer(f)
    w.writerow(['StudentId','Name','Roll','BatchName'])
    rec=[]
    while True:
        print("Enter Student Details:")
        s_id=input("Enter StudentId")
        name=input("Enter Name")
        roll=int(input("Enter roll"))
        B_name=input("Enter Batch Nmae")
        data=[s_id,name,roll,B_name]
        rec.append(data)
        ch=input("Do you want to enter more records?(y/n)")
        if ch in 'nN':
            break
    w.writerows(rec)
    f.close()

def display():
    f=open("student.csv",'r',newline='')
    r=csv.reader(f)
    for rec in r:
        print(rec)
    f.close()

def update():
    f=open("student.csv",'r',newline='')
    r=csv.reader(f) 
    s_id=input("Enter the student Id to be updated")
    nrec=[]
    found=0
    for rec in r:
        if rec[0]==s_id:
            print("Current Record: ",rec)
            rec[1]=input("Enter the new name:")
            print("Updated Record :",rec)
            found=1
            break
        nrec.append(rec)    
    if found==0:
        print("Sorry! record not found..")
    f.close()  

def delete():
    f=open("student.csv",'r',newline='')
    r=csv.reader(f) 
    s_id=input("Enter the student Id to be Deleted")
    nrec=[]
    found=0
    for rec in r:
        if rec[0]!=s_id:
            nrec.append(rec) 
        else:
            found=1
    f.close()  
    if found==0:
        print("Data Not found")
    else:
        f=open("student.csv",'w',newline='')
        r=csv.writer(f) 
        r.writerows(nrec)
        print("record deleted successfully")
        f.close()
print("Enter 0 for new student details")
print("Enter 1 for display student details")
print("Enter 2 for update student details")
print("Enter 3 for delete student details")
ch=int(input("Enter your choice : "))
if ch==0:
    add_student()
elif ch==1:
    display()
elif ch==2:
    update()
elif ch==3:
    delete()
else:
    print("Enter valid choice")