import csv
def add_student():
    f=open("batch.csv",'a',newline='')
    w=csv.writer(f)
    w.writerow(['BatchId','Batch Name','Department Name','list of Course','List Of student'])
    rec=[]
    while True:
        print("Enter Batch Details:")
        b_id=input("Enter BatchId")
        B_name=input("Enter BatchName")
        d_name=input("Enter Department Name")
        course=list(map(str,input("Enter List of Course").split()))
        B_name=list(map(str,input("Enter List of Student").split()))
        data=[b_id,B_name,d_name,course,B_name]
        rec.append(data)
        ch=input("Do you want to enter more records?(y/n)")
        if ch in 'nN':
            break
    w.writerows(rec)
    f.close()
add_student()