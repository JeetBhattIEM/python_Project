import csv
import pandas as pd
import matplotlib.pyplot as plt
from xml.dom.minidom import Element
def add_course():
    f=open("course.csv",'w',newline='')
    w=csv.writer(f)
    w.writerow(['CourseId','CourseName','Marks_obtained'])
    rec=[]
    while True:
        print("Enter Course Details: ")
        CourseId=input("Enter CourseId ")
        Coursename=input("Enter Course Name ")
        Marks_obtained={}
        n=int(input("Number of Element"))
        for i in range(n):
            S_id=input("Enter StudentId ")
            S_marks=input("Enter Marks ")
            Marks_obtained.update({S_id:S_marks})
        B_name=Marks_obtained
        data=[CourseId,Coursename,Marks_obtained]
        rec.append(data)
        ch=input("Do you want to enter more records?(y/n)")
        if ch in 'nN':
            break
    w.writerows(rec)
    f.close()
add_course()

