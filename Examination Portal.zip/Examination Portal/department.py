import csv
def add_department():
    f=open("Deparment.csv",'a',newline='')
    w=csv.writer(f)
    w.writerow(['BatchId','Batch Name','Department Name','list of Course','List Of student'])
    rec=[]
    while True:
        print("Enter New Department Details:")
        d_id=input("Enter DeptId")
        d_name=input("Enter DepartmentName")
        batch=list(map(str,input("Enter List of Batches").split()))
        data=[d_id,d_name,d_name,batch]
        rec.append(data)
        ch=input("Do you want to enter more records?(y/n)")
        if ch in 'nN':
            break
    w.writerows(rec)
    f.close()
add_department()